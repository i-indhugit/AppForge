import React from 'react';
import Navbar from '../components/Navbar';

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <Navbar />
      <main className="max-w-7xl mx-auto py-8 px-6">
        <h1 className="text-3xl font-extrabold tracking-tight mb-2 text-white">Login</h1>
        <p className="text-zinc-400 text-sm mb-8">Generated dynamic page view.</p>

        {"/* Form Widget */"}
        <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl mb-8 max-w-xl">
          <h3 className="text-lg font-semibold text-white mb-4">Login form</h3>
          <form onSubmit={(e) => e.preventDefault()}>

            <div className="mb-4">
              <label className="block text-sm font-medium text-zinc-400 mb-1 capitalize">email</label>
              <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-md p-2 text-white focus:outline-none focus:border-emerald-500 text-sm" placeholder="Enter email" />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-zinc-400 mb-1 capitalize">password</label>
              <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-md p-2 text-white focus:outline-none focus:border-emerald-500 text-sm" placeholder="Enter password" />
            </div>

            <button className="bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-bold px-4 py-2 rounded-md text-sm w-full transition-all">
              Login
            </button>
          </form>
        </div>

      </main>
    </div>
  );
}
