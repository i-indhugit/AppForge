import React from 'react';
import Navbar from '../components/Navbar';

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <Navbar />
      <main className="max-w-7xl mx-auto py-8 px-6">
        <h1 className="text-3xl font-extrabold tracking-tight mb-2 text-white">Dashboard</h1>
        <p className="text-zinc-400 text-sm mb-8">Generated dynamic page view.</p>

        {"/* Stats Summary Widget */"}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {" "}
          ['Total Items', 'Active Sessions'].map((metric) => (
            <div key={metric} className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl backdrop-blur-md">
              <div className="text-zinc-500 text-sm font-medium">{metric}</div>
              <div className="text-3xl font-bold mt-2 text-white">1,248</div>
              <div className="text-emerald-500 text-xs mt-1 font-semibold">↑ 12% vs last month</div>
            </div>
          ))
        </div>

      </main>
    </div>
  );
}
