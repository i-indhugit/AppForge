import React from 'react';
import Navbar from '../components/Navbar';

export default function ItemsPage() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <Navbar />
      <main className="max-w-7xl mx-auto py-8 px-6">
        <h1 className="text-3xl font-extrabold tracking-tight mb-2 text-white">Items</h1>
        <p className="text-zinc-400 text-sm mb-8">Generated dynamic page view.</p>

        {"/* Data Table Widget */"}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden mb-8">
          <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Items list</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-zinc-800">
              <thead className="bg-zinc-950">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-zinc-400 uppercase tracking-wider">ID</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-zinc-400 uppercase tracking-wider">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-zinc-400 uppercase tracking-wider">Created At</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800 text-sm text-zinc-300">
                <tr>
                  <td className="px-6 py-4">Sample ID Data</td>, <td className="px-6 py-4">Sample Name Data</td>, <td className="px-6 py-4">Sample Created At Data</td>
                </tr>
                <tr>
                  <td className="px-6 py-4">Another ID Data</td>, <td className="px-6 py-4">Another Name Data</td>, <td className="px-6 py-4">Another Created At Data</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </main>
    </div>
  );
}
