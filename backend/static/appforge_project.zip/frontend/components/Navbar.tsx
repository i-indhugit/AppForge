import Link from 'next/link';
import { useRouter } from 'next/router';

export default function Navbar() {
  const router = useRouter();
  const links = [
    { name: 'Login', href: '/login' }, { name: 'Dashboard', href: '/dashboard' }, { name: 'Items', href: '/items' }
  ];

  return (
    <nav className="bg-zinc-950 border-b border-zinc-800 text-white py-4 px-8 flex justify-between items-center">
      <div className="text-xl font-bold tracking-tight text-emerald-400">AppForge Generated App</div>
      <div className="flex space-x-6">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={`hover:text-emerald-400 transition-colors ${
              router.pathname === link.href ? 'text-emerald-400 font-semibold' : 'text-zinc-400'
            }`}
          >
            {link.name}
          </Link>
        ))}
      </div>
      <div>
        <button className="bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-semibold px-4 py-2 rounded-md text-sm transition-all">
          Logout
        </button>
      </div>
    </nav>
  );
}
