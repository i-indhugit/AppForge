# AppForge AI Generated Application

This application package was dynamically generated from natural language specifications.

## Project Structure
- `backend/`: FastAPI Python server with mock routes and security filters.
- `frontend/`: Next.js pages router application utilizing Tailwind styling.
- `database/`: Raw DDL file for PostgreSQL schema setup.

## Setup Instructions

### Backend
1. Navigate to `/backend`
2. Create virtual environment: `python -m venv .venv`
3. Activate it: `.venv\Scripts\activate` (Windows) or `source .venv/bin/activate` (Mac/Linux)
4. Install packages: `pip install -r requirements.txt`
5. Run server: `uvicorn app.main:app --reload`

### Frontend
1. Navigate to `/frontend`
2. Install npm modules: `npm install`
3. Run compiler project local web server: `npm run dev`

### Database
1. Run DDL schema in target PostgreSQL instance: `psql -d <db_name> -f database/schema.sql`
